# Template Matching with Weighted Templates

This repository provides a simple, self‑contained script to
**combine multiple template images into a unified representation** and
then **match that combined representation against every frame of a
video**. It is aimed at experiments like tracking contraction events
in microscope videos, but can be adapted for general template matching
scenarios.

## Contents

- `combine_and_match.py`: Command‑line script that performs two tasks:
  1. **Template combination** — Load all images from the specified
     directory, resize them to the size of the first template, apply
     basic preprocessing (CLAHE + blur), normalize them, and compute an
     average prototype. The resulting prototype is saved as
     `combined_template.png` for inspection.
  2. **Video matching** — If a video is provided, the script
     processes it frame by frame. It performs a *weighted fusion* of
     correlation responses from all templates to locate the best match
     in each frame. To speed up processing, it first searches inside
     a margin around the previous frame’s bounding box and falls back
     to a global search if the local match score is too low. It saves
     an annotated video (`annotated.mp4`) and a CSV file (`matches.csv`)
     containing the bounding box and correlation score for each frame.

- `templates/` (not included in this zip): Directory where you should
  place your template images. All common image formats (PNG, JPG, etc.)
  are supported.

## Installation

This script depends on the following Python libraries:

```
pip install opencv-python-headless numpy
```

Make sure you have `ffmpeg` installed if you plan to work with certain
video formats not natively supported by OpenCV.

## Usage

### 1. Combine Templates Only

If you only want to combine templates and inspect the resulting
prototype, run:

```
python3 combine_and_match.py \
    --template-dir path/to/your/templates \
    --output-dir path/to/output
```

The combined prototype will be saved as `combined_template.png` in
`output-dir`.

### 2. Match Templates Against a Video

To process a video frame by frame and record the best match per frame:

```
python3 combine_and_match.py \
    --template-dir path/to/your/templates \
    --video-path path/to/video.mp4 \
    --output-dir path/to/output \
    --margin 80 \
    --min-score 0.45
```

- **`--margin`**: Number of pixels around the last bounding box to
  search in the next frame. Larger margins improve robustness at the
  cost of speed.
- **`--min-score`**: If the correlation score from the local search
  falls below this value, the script falls back to searching the
  entire frame.

The following files are created in `output-dir`:

- `combined_template.png`: Prototype obtained by averaging all
  normalized templates.
- `annotated.mp4`: Video with the detected bounding box drawn on each
  frame. The correlation score is also displayed.
- `matches.csv`: CSV file containing one row per frame with the
  following columns:

  | frame | time_s | x1 | y1 | x2 | y2 | score |
  |------:|-------:|---:|---:|---:|---:|------:|
  |    10 | 0.333 |  50|  60|  90| 100| 0.78  |

  where `(x1, y1, x2, y2)` is the bounding box of the detected match
  and `score` is the correlation score (1.0 is a perfect match).

## Notes and Tips

- All templates must depict the same feature at approximately the
  **same scale** and orientation for the weighted matching to be
  effective. If your templates vary in zoom, consider creating
  separate template sets per scale or extending the script to handle
  multi‑scale matching.
- The script uses an adaptive histogram equalization (CLAHE) and
  Gaussian blur to improve robustness against illumination changes.
- For real microscope datasets, consider tweaking `--margin` and
  `--min-score` depending on how fast the contraction moves and how
  similar consecutive frames are.

Feel free to adapt and extend this script according to your needs!
