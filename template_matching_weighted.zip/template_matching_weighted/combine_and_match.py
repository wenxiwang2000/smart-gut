#!/usr/bin/env python3
"""
combine_and_match.py
====================

This utility combines multiple template images into a single set of
normalized templates with equal weighting and then performs weighted
template matching on an input video. It automatically resizes all
templates to a common scale (based on the first template found) and
preprocesses them to improve robustness against varying illumination.

When run on a video, the script processes each frame, searching first
within a region around the last detected match (to accelerate
matching) and falling back to a global search if the local match
confidence is too low. Detected bounding boxes and correlation scores
are written to a CSV file, and an annotated output video is saved
with the detection boxes drawn on each frame. A combined prototype
template image is also saved to disk for inspection.

Usage:
    python3 combine_and_match.py --template-dir templates \
        --video-path path/to/video.mp4 --output-dir results

Arguments:
    --template-dir:  Directory containing one or more template images.
                     Supported formats include PNG and JPEG. The script
                     ignores any non-image files.
    --video-path:    Path to a video file. If provided, the script
                     will perform template matching on each frame and
                     produce an annotated video and CSV file. If
                     omitted, only the combined template is created.
    --output-dir:    Directory where output files will be saved. It will
                     be created if it does not exist. Defaults to
                     "output".
    --margin:        Number of pixels to expand the search region around
                     the last detected bounding box. A larger margin
                     increases robustness but reduces speed. Default: 80.
    --min-score:     Minimum correlation score required to accept a local
                     match. If the score falls below this threshold,
                     the script falls back to searching the entire
                     frame. Default: 0.45.

This script requires OpenCV (cv2) and NumPy. You can install these
dependencies via pip:
    pip install opencv-python-headless numpy

Author: OpenAI Assistant
"""

import argparse
import csv
import os
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np


def preprocess_image(gray: np.ndarray) -> np.ndarray:
    """Apply contrast-limited adaptive histogram equalization and Gaussian blur.

    These operations help to normalize lighting variations and reduce
    high-frequency noise, which improves template matching robustness.

    Args:
        gray: Grayscale image as a NumPy array of dtype uint8.

    Returns:
        Preprocessed grayscale image of dtype uint8.
    """
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    eq = clahe.apply(gray)
    blurred = cv2.GaussianBlur(eq, (3, 3), 0)
    return blurred


def load_and_prepare_templates(template_dir: Path) -> Tuple[List[np.ndarray], np.ndarray]:
    """Load template images from a directory and normalize them.

    All templates are resized to the dimensions of the first valid image
    encountered. Each template is converted to grayscale, preprocessed
    with CLAHE and Gaussian blur, then normalized to zero mean and unit
    variance. Equal weights are assigned to each template.

    Args:
        template_dir: Path to the directory containing template images.

    Returns:
        A tuple (templates, weights):
            templates: List of normalized float32 templates with shape
                (height, width).
            weights:  1D NumPy array of float32 containing equal weights
                for each template (sums to 1).
    """
    templates: List[np.ndarray] = []
    first_size: Optional[Tuple[int, int]] = None
    for entry in sorted(template_dir.iterdir()):
        if not entry.is_file():
            continue
        # Attempt to read the image
        img = cv2.imread(str(entry), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        # Preprocess the image
        img = preprocess_image(img)
        # Set the reference size on the first valid template
        if first_size is None:
            first_size = img.shape[:2]
        # Resize to the reference size
        img_resized = cv2.resize(img, (first_size[1], first_size[0]))  # width, height order
        # Normalize to zero mean and unit variance
        img_norm = img_resized.astype(np.float32)
        img_norm = (img_norm - img_norm.mean()) / (img_norm.std() + 1e-6)
        templates.append(img_norm)
    if not templates:
        raise RuntimeError(f"No valid template images found in {template_dir}")
    # Create equal weights
    weights = np.ones(len(templates), dtype=np.float32)
    weights /= weights.sum()
    return templates, weights


def save_combined_template(templates: List[np.ndarray], output_path: Path) -> None:
    """Save the average of normalized templates as an 8-bit image.

    The combined template is created by averaging the normalized
    templates. The result is rescaled to the 0–255 range and saved
    as PNG for inspection. Note that the combined template is not
    directly used for matching; it is provided purely for visual
    reference.

    Args:
        templates: List of normalized templates.
        output_path: Path to the output image file.
    """
    # Compute the average of normalized templates
    proto = np.mean(np.stack(templates, axis=0), axis=0)
    # Normalize to 0–255 for saving
    proto_u8 = cv2.normalize(proto, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    cv2.imwrite(str(output_path), proto_u8)


def weighted_match(
    frame_region: np.ndarray,
    templates: List[np.ndarray],
    weights: np.ndarray,
) -> Tuple[Tuple[int, int, int, int], float]:
    """Perform weighted template matching within a region.

    Args:
        frame_region: Grayscale, preprocessed ROI from the video frame.
        templates:    List of normalized templates (all same size).
        weights:      1D weights array summing to 1 (same length as templates).

    Returns:
        bbox:  Tuple (x1, y1, x2, y2) relative to the region's origin.
        score: Maximum correlation score across all locations.

    The bounding box coordinates are relative to the region's top-left
    corner (0,0). The caller must offset these coordinates when
    translating back to the full-frame coordinate system.
    """
    fused = None
    th, tw = templates[0].shape[:2]
    for t, w in zip(templates, weights):
        res = cv2.matchTemplate(frame_region, t, cv2.TM_CCOEFF_NORMED)
        if fused is None:
            fused = w * res
        else:
            fused += w * res
    _, max_val, _, max_loc = cv2.minMaxLoc(fused)
    x, y = max_loc
    bbox = (x, y, x + tw, y + th)
    return bbox, float(max_val)


def clamp_region(
    x1: int, y1: int, x2: int, y2: int, width: int, height: int
) -> Tuple[int, int, int, int]:
    """Clamp a region to the bounds of the frame.

    Args:
        x1, y1, x2, y2: Coordinates of the region.
        width, height: Dimensions of the frame.

    Returns:
        A clamped region as a tuple (x1, y1, x2, y2) where
        0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height.
    """
    x1 = max(0, min(width - 1, x1))
    y1 = max(0, min(height - 1, y1))
    x2 = max(1, min(width, x2))
    y2 = max(1, min(height, y2))
    return x1, y1, x2, y2


def process_video(
    video_path: Path,
    templates: List[np.ndarray],
    weights: np.ndarray,
    output_dir: Path,
    margin: int,
    min_score: float,
) -> None:
    """Process a video frame by frame using weighted template matching.

    Args:
        video_path: Path to the input video file.
        templates:  List of normalized templates.
        weights:    Weights for combining templates.
        output_dir: Directory in which to save the annotated video and CSV.
        margin:     Search margin around previous bounding box (in pixels).
        min_score:  Minimum correlation score to accept a local match.

    Saves:
        - annotated.mp4: Video with bounding boxes drawn on each frame.
        - matches.csv:   CSV file with detection results per frame.
    """
    # Open video
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video file: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    # Prepare output video writer
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out_video_path = output_dir / "annotated.mp4"
    writer = cv2.VideoWriter(str(out_video_path), fourcc, fps, (frame_width, frame_height))
    # Prepare CSV writer
    csv_path = output_dir / "matches.csv"
    csv_file = open(csv_path, "w", newline="")
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow([
        "frame", "time_s", "x1", "y1", "x2", "y2", "score"
    ])
    # Frame processing loop
    last_bbox: Optional[Tuple[int, int, int, int]] = None
    frame_idx = 0
    try:
        while True:
            ok, frame_bgr = cap.read()
            if not ok:
                break
            frame_gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
            # Preprocess the frame
            frame_proc = preprocess_image(frame_gray)
            # Determine search region
            region = None
            if last_bbox is not None:
                lx1, ly1, lx2, ly2 = last_bbox
                region = clamp_region(
                    lx1 - margin, ly1 - margin, lx2 + margin, ly2 + margin,
                    frame_width, frame_height
                )
            # Local search
            bbox_local = None
            score_local = -1.0
            if region is not None:
                x1r, y1r, x2r, y2r = region
                roi = frame_proc[y1r:y2r, x1r:x2r]
                if roi.shape[0] >= templates[0].shape[0] and roi.shape[1] >= templates[0].shape[1]:
                    bbox_local, score_local = weighted_match(roi, templates, weights)
                    # Offset bbox_local to full frame coordinates
                    if bbox_local is not None:
                        bx1, by1, bx2, by2 = bbox_local
                        bbox_local = (x1r + bx1, y1r + by1, x1r + bx2, y1r + by2)
            # If local search is inadequate, perform global search
            if bbox_local is None or score_local < min_score:
                bbox_global, score_global = weighted_match(frame_proc, templates, weights)
                bbox_local = bbox_global
                score_local = score_global
            # Update last_bbox
            last_bbox = bbox_local
            # Draw bounding box and score
            x1, y1, x2, y2 = bbox_local
            cv2.rectangle(frame_bgr, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.putText(
                frame_bgr,
                f"score={score_local:.2f}",
                (x1, max(20, y1 - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 0, 255),
                1,
            )
            # Write results
            time_s = frame_idx / fps
            csv_writer.writerow([
                frame_idx, f"{time_s:.3f}", x1, y1, x2, y2, f"{score_local:.4f}"
            ])
            writer.write(frame_bgr)
            frame_idx += 1
    finally:
        cap.release()
        writer.release()
        csv_file.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Combine templates and match them in a video.")
    parser.add_argument(
        "--template-dir",
        type=Path,
        required=True,
        help="Directory containing template images.",
    )
    parser.add_argument(
        "--video-path",
        type=Path,
        default=None,
        help="Path to the video file to process. If omitted, only the combined template is saved.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("output"),
        help="Directory to save output files.",
    )
    parser.add_argument(
        "--margin",
        type=int,
        default=80,
        help="Search margin in pixels around the last bounding box.",
    )
    parser.add_argument(
        "--min-score",
        type=float,
        default=0.45,
        help="Minimum correlation score to accept a local match before falling back to global search.",
    )
    args = parser.parse_args()
    # Ensure template directory exists
    if not args.template_dir.is_dir():
        raise FileNotFoundError(f"Template directory not found: {args.template_dir}")
    # Prepare output directory
    args.output_dir.mkdir(parents=True, exist_ok=True)
    # Load and prepare templates
    templates, weights = load_and_prepare_templates(args.template_dir)
    # Save the combined template image
    combined_template_path = args.output_dir / "combined_template.png"
    save_combined_template(templates, combined_template_path)
    print(f"Saved combined template to: {combined_template_path}")
    # If video is provided, process it
    if args.video_path is not None:
        if not args.video_path.is_file():
            raise FileNotFoundError(f"Video file not found: {args.video_path}")
        process_video(
            args.video_path,
            templates,
            weights,
            args.output_dir,
            args.margin,
            args.min_score,
        )
        print(f"Finished processing video. Results saved in {args.output_dir}")
    else:
        print("No video specified; only the combined template has been saved.")


if __name__ == "__main__":
    main()
