Place your template images here.
